var GeneralTouchEvent = {
	MOVE : "generalTouchMovement",
	START : "generalTouchStart",
	END : "generalTouchEnd",
}